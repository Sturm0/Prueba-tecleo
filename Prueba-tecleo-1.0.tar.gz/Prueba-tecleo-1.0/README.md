Dentro de la carpeta compilado se encuentra el .out para utilizar en sistemas GNU/Linux

Para salir del programa escribir "salir" (sin las comillas).
